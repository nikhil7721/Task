package com.pertsol.exception;

public class CommentIdNotFoundException extends RuntimeException {
	
	public CommentIdNotFoundException(String msg) {
		super(msg);
		
	}

}
