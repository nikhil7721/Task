package com.employee.exception;

public class EmailIdAlreadyPresentException extends RuntimeException{
	
	public  EmailIdAlreadyPresentException(String msg) {
		super(msg);
		
	}

}
