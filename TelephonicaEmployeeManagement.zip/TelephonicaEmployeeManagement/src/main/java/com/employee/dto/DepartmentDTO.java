package com.employee.dto;



import lombok.Data;



@Data
public class DepartmentDTO {
	
	private Long departmentId;
	
	
	private String departmentName;
	

	

}
